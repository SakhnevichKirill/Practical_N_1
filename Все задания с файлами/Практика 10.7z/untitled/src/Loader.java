import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Loader {
    public static void main(String[] args) {
        read3();
    }
    public static void getFile() {
        File file = new File("C:/Users/IVC1-5/Desktop");
        if(file.isDirectory()) {
            File[] files = file.listFiles();
            for (File item : files) {
                System.out.println(item.getPath());
            }
        }
    }


    public static void read1() {
        StringBuffer buffer = new StringBuffer();

        try {
            FileInputStream inputStream = new FileInputStream("data/file1.txt");

            while (true) {
                int code = inputStream.read();

                if (code < 0)
                    break;

                char ch = (char) code;
                buffer.append(ch);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        System.out.println(buffer);
    }

    public static void read2() {
        StringBuffer buffer = new StringBuffer();

        try {
            BufferedReader reader = new BufferedReader(new FileReader("data/file1.txt"));

            while (true) {
                String line = reader.readLine();

                if(line == null)
                    break;

                buffer.append(line + "\n");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        System.out.println(buffer);
    }

    public static void read3() {
        StringBuffer buffer = new StringBuffer();

        try {
            List<String> files = Files.readAllLines(Paths.get("data/file1.txt"));

            for(String item : files)
            {
                buffer.append(item + "\n");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        System.out.println(buffer);
    }
}
