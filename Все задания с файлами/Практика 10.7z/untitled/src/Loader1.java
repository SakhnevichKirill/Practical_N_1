import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Loader1 {
    public static void main(String[] args) {
        pr3();

        System.out.println("adawdawd");
    }

    public static void pr1() {
        try {
            FileOutputStream os = new FileOutputStream("data/file1.txt");

            for (int i = 0; i <= 1000; i++)
            {
               for(char c : Integer.toString(i).toCharArray()) {
                   os.write(c);

               }
                os.write('\n');

            }
            os.flush();
            os.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void pr2() {
        try {
            PrintWriter writer = new PrintWriter("data/file2.txt");

            for (int i = 0; i <= 1000; i++) {
                writer.write(i + "\n");
            }
            writer.flush();
            writer.close();

        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public static void pr3() {
        try {
            ArrayList<String> list = new ArrayList<>();
            for (int i = 0; i <= 1000; i++) {
                list.add(Integer.toString(i));
            }
            Files.write(Paths.get("data/file3.txt"), list);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
